from fastapi import FastAPI, HTTPException, Depends, Security
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from datetime import datetime
import os
from dotenv import load_dotenv
from supabase import create_client, Client

from pathlib import Path

load_dotenv(Path(__file__).parent / ".env")

app = FastAPI(title="IoT Student Counter API")

API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

DEVICE_API_KEY = os.getenv("DEVICE_API_KEY")
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
    raise ValueError("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set in .env")

supabase = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def verify_api_key(api_key: str = Security(api_key_header)):
    if DEVICE_API_KEY and api_key != DEVICE_API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key

@app.get("/api")
async def health_check():
    return {"status": "online", "service": "IoT Student Counter API"}

@app.get("/api/state")
async def get_state():
    result = supabase.table("counters").select("*").eq("id", 1).execute()
    
    if not result.data:
        supabase.table("counters").insert({
            "id": 1,
            "entered": 0,
            "exited": 0,
            "room_capacity": 80
        }).execute()
        result = supabase.table("counters").select("*").eq("id", 1).execute()
    
    row = result.data[0]
    inside = row["entered"] - row["exited"]
    occupancy = (inside / row["room_capacity"]) * 100 if row["room_capacity"] > 0 else 0
    
    return {
        "entered": row["entered"],
        "exited": row["exited"],
        "inside": inside,
        "roomCapacity": row["room_capacity"],
        "occupancyPercentage": round(occupancy, 2)
    }

@app.post("/api/entry")
async def record_entry():
    current = supabase.table("counters").select("entered").eq("id", 1).execute().data[0]["entered"]
    supabase.table("counters").update({"entered": current + 1}).eq("id", 1).execute()
    
    supabase.table("events").insert({
        "type": "entry",
        "source": "manual",
        "timestamp": datetime.now().isoformat(),
        "device_id": None
    }).execute()
    
    return await get_state()

@app.post("/api/exit")
async def record_exit():
    current = supabase.table("counters").select("exited").eq("id", 1).execute().data[0]["exited"]
    supabase.table("counters").update({"exited": current + 1}).eq("id", 1).execute()
    
    supabase.table("events").insert({
        "type": "exit",
        "source": "manual",
        "timestamp": datetime.now().isoformat(),
        "device_id": None
    }).execute()
    
    return await get_state()

@app.post("/api/sensor-event")
async def sensor_event(event: dict, api_key: str = Depends(verify_api_key)):
    if event.get("event") not in ["entry", "exit"]:
        raise HTTPException(status_code=400, detail="Invalid event type")
    
    device_id = event.get("source", "esp32-door-1")
    
    device_result = supabase.table("devices").select("status").eq("id", device_id).execute()
    
    if not device_result.data:
        supabase.table("devices").insert({
            "id": device_id,
            "name": f"Device {device_id}",
            "status": "active",
            "registered_at": datetime.now().isoformat(),
            "last_seen": None
        }).execute()
    
    device_status = device_result.data[0]["status"] if device_result.data else "active"
    if device_status == "inactive":
        raise HTTPException(status_code=403, detail="Device is not active")
    
    event_type = event.get("event")
    
    if event_type == "entry":
        current = supabase.table("counters").select("entered").eq("id", 1).execute().data[0]["entered"]
        supabase.table("counters").update({"entered": current + 1}).eq("id", 1).execute()
    else:
        current = supabase.table("counters").select("exited").eq("id", 1).execute().data[0]["exited"]
        supabase.table("counters").update({"exited": current + 1}).eq("id", 1).execute()
    
    supabase.table("events").insert({
        "type": event_type,
        "source": "esp32",
        "timestamp": datetime.now().isoformat(),
        "device_id": device_id
    }).execute()
    
    supabase.table("devices").update({
        "last_seen": datetime.now().isoformat()
    }).eq("id", device_id).execute()
    
    return await get_state()

@app.post("/api/devices/register")
async def register_device(device: dict, api_key: str = Depends(verify_api_key)):
    device_id = device.get("device_id")
    name = device.get("name", f"Device {device_id}")
    
    if not device_id:
        raise HTTPException(status_code=400, detail="device_id is required")
    
    existing = supabase.table("devices").select("*").eq("id", device_id).execute()
    
    if existing.data:
        return {"message": "Device already registered", "status": existing.data[0]["status"]}
    
    supabase.table("devices").insert({
        "id": device_id,
        "name": name,
        "status": "pending",
        "registered_at": datetime.now().isoformat(),
        "last_seen": None
    }).execute()
    
    return {"message": "Device registered successfully", "status": "pending"}

@app.get("/api/devices")
async def list_devices():
    result = supabase.table("devices").select("*").execute()
    return result.data

@app.get("/api/devices/{device_id}")
async def get_device(device_id: str):
    result = supabase.table("devices").select("*").eq("id", device_id).execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return result.data[0]

@app.get("/api/devices/{device_id}/events")
async def get_device_events(device_id: str, limit: int = 100):
    # Search in both device_id and source fields
    result = supabase.table("events").select("*").or_(f"device_id.eq.{device_id},source.eq.{device_id}").order("timestamp", desc=True).limit(limit).execute()
    return result.data

@app.put("/api/devices/{device_id}/activate")
async def activate_device(device_id: str):
    result = supabase.table("devices").select("*").eq("id", device_id).execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Device not found")
    
    supabase.table("devices").update({"status": "active"}).eq("id", device_id).execute()
    
    return {"message": "Device activated successfully"}

@app.put("/api/devices/{device_id}/deactivate")
async def deactivate_device(device_id: str):
    result = supabase.table("devices").select("*").eq("id", device_id).execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Device not found")
    
    supabase.table("devices").update({"status": "inactive"}).eq("id", device_id).execute()
    
    return {"message": "Device deactivated successfully"}

@app.post("/api/reset")
async def reset_counts():
    supabase.table("counters").update({"entered": 0, "exited": 0}).eq("id", 1).execute()
    supabase.table("events").delete().neq("id", 0).execute()
    
    return await get_state()

@app.get("/api/history")
async def get_history(limit: int = 100):
    result = supabase.table("events").select("*").order("timestamp", desc=True).limit(limit).execute()
    return result.data

@app.get("/api/analytics")
async def get_analytics():
    state_result = supabase.table("counters").select("*").eq("id", 1).execute()
    state = state_result.data[0] if state_result.data else {"entered": 0, "exited": 0, "room_capacity": 80}
    
    entries_result = supabase.table("events").select("*", count="exact").eq("type", "entry").execute()
    total_entries = entries_result.count
    
    exits_result = supabase.table("events").select("*", count="exact").eq("type", "exit").execute()
    total_exits = exits_result.count
    
    inside = state["entered"] - state["exited"]
    
    return {
        "currentInside": inside,
        "totalEntries": total_entries,
        "totalExits": total_exits,
        "peakOccupancy": inside,
        "roomCapacity": state["room_capacity"]
    }

@app.put("/api/capacity")
async def update_capacity(capacity: dict):
    supabase.table("counters").update({"room_capacity": capacity.get("room_capacity", 80)}).eq("id", 1).execute()
    return await get_state()
